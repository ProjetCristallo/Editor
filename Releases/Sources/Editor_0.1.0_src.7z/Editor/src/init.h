#ifndef __INIT__
#define __INIT__

bool init();

void readConfig();

#endif
